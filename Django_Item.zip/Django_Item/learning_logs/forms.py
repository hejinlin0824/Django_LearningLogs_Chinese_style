from django import forms

from .models import Topic,Entry

class TopicForm(forms.ModelForm):
    class Meta:
        model = Topic#model的作用：指定表单对应的模型
        fields = ['text']#fields的作用：指定表单中需要包含的字段
        labels = {'text':''}#labels的作用：给text字段添加标签，目前是不要添加标签

class EntryForm(forms.ModelForm):
    class Meta:
        model = Entry
        fields = ['text']#fields的作用：指定表单中需要包含的字段
        labels = {'text':''}#labels的作用：给text字段添加标签，目前是不要添加标签
        widgets = {'text':forms.Textarea(attrs={'cols':80})}#widgets的作用：给text字段添加样式
