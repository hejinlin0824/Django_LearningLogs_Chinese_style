from django.urls import path,include
from . import views
app_name = 'users'

urlpatterns = [
    path('',include('django.contrib.auth.urls')),#引入Django内置的URL路由配置,
    # 注册
    path('register/',views.register,name='register'),
]